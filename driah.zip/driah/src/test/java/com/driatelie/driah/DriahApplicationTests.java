package com.driatelie.driah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriahApplicationTests {

	@Test
	void contextLoads() {
	}

}
